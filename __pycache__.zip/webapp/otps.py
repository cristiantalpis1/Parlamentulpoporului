from random import randint

otp = randint(100000, 999999)
otp_phone = randint(1000,9999)